function myFunction() {
    document.getElementById("sideBarb").style.border = "solid #0000FF";
}